"""One short offline gate; owns only uniquely labelled disposable containers."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import uuid

ROOT = Path('/home/jon/Desktop/workshop/last_chessism')
BASE = Path('/tmp/chessism-canonical-numeric-20261119')
PG = 'sha256:9a18aed4ecdd7db9e63f876ace8ef65166d9358ece23893eed8db9b1a7fa0b95'
API = 'sha256:ba1c705b2daf726ab8c6b4036f945413585fb657590933e2673e0424970721be'
DOCKER = ['docker', '--host', 'unix:///var/run/docker.sock']

def docker(*args, check=True, timeout=35):
    result = subprocess.run([*DOCKER, *args], text=True, capture_output=True, timeout=timeout)
    if check and result.returncode:
        raise RuntimeError(f'Docker {args[0]} failed: {result.stderr.strip()}')
    return result

if __name__ == '__main__':
    stage = sys.argv[1]
    assert stage in ('red','green')
    owner = 'chessism-numeric-' + uuid.uuid4().hex[:10]
    socket = BASE / owner
    socket.mkdir(mode=0o777)
    socket.chmod(0o777)
    created = []
    record = {'stage': stage, 'owner': owner, 'images': {'postgres':PG, 'python':API},
              'socket':str(socket), 'network':'none', 'ports':[], 'cleanup':[]}
    tracked = subprocess.check_output(['git','ls-files','*.py','*.sql'], cwd=ROOT, text=True).splitlines()
    tracked += ['tests/check_canonical_score_bounds_postgres.py']
    hashes = {name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in tracked if (ROOT/name).is_file()}
    (BASE/'evidence'/f'{stage}-hashes.json').write_text(json.dumps(hashes,sort_keys=True,indent=2)+'\n')
    started = time.monotonic()
    try:
        pg_name = owner+'-pg'
        docker('create','--pull','never','--name',pg_name,'--label','chessism.numeric.owner='+owner,
               '--network','none','--read-only','--user','1000:1000','--cpus','2','--memory','1g','--pids-limit','128',
               '--tmpfs','/tmp:rw,size=1g','--tmpfs','/var/lib/postgresql/data:rw,size=1m',
               '--mount',f'type=bind,source={socket},target=/var/run/postgresql',
               '--env','PGDATA=/tmp/pgdata','--env','POSTGRES_USER=test',
               '--env','POSTGRES_HOST_AUTH_METHOD=trust','--env','POSTGRES_DB=chessism_canonical_test',
               '--env','PGPORT=55432',PG,'-c','listen_addresses=','-c','port=55432',
               '-c','unix_socket_directories=/var/run/postgresql')
        created.append(pg_name)
        docker('start',pg_name)
        deadline = time.monotonic()+30
        while True:
            ready = docker('exec',pg_name,'sh','-c',
                'test "$(cat /proc/1/comm)" = postgres && pg_isready -h /var/run/postgresql -p 55432 -U test -d chessism_canonical_test',check=False)
            if ready.returncode == 0: break
            if time.monotonic()>deadline: raise RuntimeError('Disposable PostgreSQL did not become ready')
            time.sleep(.25)
        runner = owner+'-tests'
        docker('create','--pull','never','--name',runner,'--label','chessism.numeric.owner='+owner,
               '--network','none','--read-only','--user','1000:1000','--cpus','2','--memory','2g','--pids-limit','256',
               '--tmpfs','/tmp:rw,size=256m',
               '--mount',f'type=bind,source={ROOT},target=/workspace,readonly',
               '--mount','type=bind,source=/dev/null,target=/workspace/.env,readonly',
               '--mount',f'type=bind,source={BASE}/run_tests.py,target=/run_tests.py,readonly',
               '--mount',f'type=bind,source={BASE}/evidence,target=/evidence',
               '--mount',f'type=bind,source={socket},target={socket}',
               '--workdir','/workspace','--env','PYTHONDONTWRITEBYTECODE=1','--env','PYTHONUNBUFFERED=1',
               '--env','PYTHONPATH=/workspace:/workspace/tests:/workspace/stockfish-batch-worker:/workspace/stockfish-service',
               '--env',f'CHESSISM_CANONICAL_TEST_SOCKET={socket}',
               '--env','DATABASE_URL=postgresql+asyncpg://test:test@127.0.0.1:1/test',
               '--env','AUTH_COOKIE_NAME=synthetic_session','--env','AUTH_GATE_COOKIE_NAME=synthetic_gate',
               '--env','AUTH_SESSION_TTL_DAYS=1','--env','AUTH_GATE_TTL_MINUTES=1',
               '--env','AUTH_COOKIE_SECURE=false','--env','SUPERADMIN_GATE_CODE=synthetic-only',
               '--entrypoint','python',API,'-B','/run_tests.py',stage)
        created.append(runner)
        with (BASE/'evidence'/f'{stage}.log').open('w') as out:
            completed = subprocess.run([*DOCKER,'start','--attach',runner],stdout=out,stderr=subprocess.STDOUT,timeout=200)
        state = json.loads(docker('inspect',runner,'--format','{{json .State}}').stdout)
        record['state'] = state
        record['exit_code'] = state['ExitCode']
        print(f'{stage}: exit={state["ExitCode"]}; log={BASE}/evidence/{stage}.log',flush=True)
    finally:
        for name in reversed(created):
            identity = json.loads(docker('inspect',name,'--format','{{json .Config.Labels}}').stdout)
            assert identity.get('chessism.numeric.owner') == owner
            state = json.loads(docker('inspect',name,'--format','{{json .State}}').stdout)
            if state['Running']: docker('stop','--timeout','30',name,timeout=40)
            if name.endswith('-pg'):
                (BASE/'evidence'/f'{stage}-postgres.log').write_text(docker('logs',name).stdout+docker('logs',name).stderr)
            docker('rm',name)
            record['cleanup'].append({'name':name,'removed':docker('inspect',name,check=False).returncode!=0})
        record['elapsed_seconds']=time.monotonic()-started
        (BASE/'evidence'/f'{stage}-environment.json').write_text(json.dumps(record,indent=2)+'\n')
    sys.exit(record.get('exit_code',1))
