import json
import os
from pathlib import Path
import sys
import time
import unittest

class Result(unittest.TextTestResult):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.identities = []
    def startTest(self, test):
        self.identities.append(test.id())
        super().startTest(test)

if __name__ == '__main__':
    stage = sys.argv[1]
    names = ['tests.check_canonical_score_bounds_postgres.CanonicalScoreBoundsTests']
    if stage == 'green':
        names += ['tests.check_canonical_analysis_views_postgres.CanonicalAnalysisViewTests',
                  'tests.check_canonical_recovery_postgres.CanonicalRecoveryTests',
                  'tests.test_cuda_accuracy.AccuracyTests',
                  'tests.test_evaluation_contract',
                  'tests.test_pipeline_helpers.StockfishSerializationTests',
                  'tests.test_pipeline_helpers.TablebaseAnalysisTests',
                  'tests.test_pipeline_helpers.PlayerHeroAnalyticsTests.test_lichess_winning_chances_are_symmetric_and_cap_at_1000_cp',
                  'tests.test_pipeline_helpers.PlayerHeroAnalyticsTests.test_lichess_move_accuracy_is_player_oriented_and_bounded']
        # Only the six matrix-specific checks; do not duplicate all inherited CUDA tests.
        from tests.check_canonical_matrices_postgres import CanonicalMatrixTests
        names += ['tests.check_canonical_matrices_postgres.CanonicalMatrixTests.' + name
                  for name in CanonicalMatrixTests.__dict__ if name.startswith('test_')]
    start = time.monotonic()
    suite = unittest.defaultTestLoader.loadTestsFromNames(names)
    result = unittest.TextTestRunner(verbosity=2, resultclass=Result).run(suite)
    record = {'stage': stage, 'runtime': sys.version, 'elapsed_seconds': time.monotonic()-start,
              'selected': names, 'tests_run': result.testsRun, 'identities': result.identities,
              'failures': [(t.id(), e) for t,e in result.failures],
              'errors': [(t.id(), e) for t,e in result.errors],
              'skipped': [(t.id(), e) for t,e in result.skipped],
              'successful': result.wasSuccessful()}
    Path('/evidence/' + stage + '-results.json').write_text(json.dumps(record, indent=2)+'\n')
    sys.exit(0 if result.wasSuccessful() and not result.skipped else 1)
