"""Structured unittest evidence and live check identity for this disposable run."""
import json
import sys
import time
import unittest
from monitor import ROOT,update

name=sys.argv[1]
modules={'foundation': ['tests.check_canonical_schema_postgres', 'tests.check_canonical_cuda_postgres', 'tests.test_cuda_resource_cleanup', 'tests.test_player_game_explorer_query', 'tests.test_cuda_summary_routes', 'tests.test_player_time_result_filters', 'tests.test_canonical_blunders', 'tests.test_player_stockfish_summary', 'tests.test_cuda_input_snapshot', 'tests.test_cuda_accuracy', 'tests.test_cuda_behavior', 'tests.test_cuda_salience_daily', 'tests.test_cuda_blunder_summary', 'tests.test_cuda_batch_budget', 'tests.test_position_frequency']}[name]
assert isinstance(modules, list) and all(isinstance(module, str) for module in modules)
class Progress(unittest.TextTestResult):
    def startTest(self,test):
        super().startTest(test);update(current_test=test.id())
    def stopTest(self,test):
        super().stopTest(test);update(tests_completed=self.testsRun)
suite=unittest.defaultTestLoader.loadTestsFromNames(modules)
update(tests_total=suite.countTestCases(),tests_completed=0)
started=time.time()
result=unittest.TextTestRunner(verbosity=2,resultclass=Progress).run(suite)
report={'suite':name,'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
        'skips':len(result.skipped),'elapsed_seconds':time.time()-started,
        'failure_details':result.failures,'error_details':result.errors,'skip_details':result.skipped,
        'python':sys.version}
for field in ['failure_details','error_details','skip_details']:
    report[field]=[{'test':test.id(),'detail':detail} for test,detail in report[field]]
(ROOT/(name+'-results.json')).write_text(json.dumps(report,indent=2)+'\n')
sys.exit(0 if result.wasSuccessful() and not result.skipped else 1)
