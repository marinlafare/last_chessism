"""A3.2 cuda verification only: private PG/Redis, readonly source, no network, owned cleanup."""
from pathlib import Path
import ast
import hashlib
import json
import os
import signal
import subprocess
import sys
import time
import traceback
from uuid import uuid4
from monitor import ROOT,update

REPO=Path('/home/jon/Desktop/workshop/last_chessism')
DOCKER=['docker','--host','unix:///var/run/docker.sock']
ENV={k:os.environ[k] for k in ('PATH','LANG') if k in os.environ}
RUN=uuid4().hex
OWNED=[]
REPORT={'run_id':RUN,'containers':{},'results':{},'production_access':False}
USER=f'{os.getuid()}:{os.getgid()}'
PG=ROOT/'pg';REDIS=ROOT/'redis'
SOURCE_FILES=[*json.loads((ROOT/'protected-baseline.json').read_text()),
    *json.loads((ROOT/'new-inputs.json').read_text())]


def command(argv,timeout=60):
    try:
        return subprocess.run(argv,env=ENV,check=True,text=True,capture_output=True,timeout=timeout)
    except subprocess.CalledProcessError as error:
        (ROOT/('command-error-'+uuid4().hex+'.json')).write_text(json.dumps({
            'argv':argv,'exit_code':error.returncode,'stdout':error.stdout,'stderr':error.stderr},indent=2)+'\n')
        raise


def snapshot():
    for p in json.loads((ROOT/'removed-baseline-inputs.json').read_text()):
        assert not (REPO/p).exists(), 'Retired module reappeared: '+p
    return {p:hashlib.sha256((REPO/p).read_bytes()).hexdigest() for p in SOURCE_FILES}


def stage(name):
    update(stage=name,current_test=None,tests_total=None,tests_completed=0)
    print(name,flush=True)


def create(role,args):
    name='chessism-canonical-a3-cuda-'+RUN[:10]+'-'+role
    argv=DOCKER+['create','--pull','never','--name',name,'--label','chessism.a3.cuda.run='+RUN,*args]
    (ROOT/(role+'-command.json')).write_text(json.dumps(argv,indent=2)+'\n')
    command(argv);OWNED.append(name)
    data=json.loads(command(DOCKER+['inspect',name]).stdout)[0]
    assert data['Config']['Labels']['chessism.a3.cuda.run']==RUN
    assert data['HostConfig']['NetworkMode']=='none' and not data['HostConfig'].get('PortBindings')
    assert not any(m['Type']=='volume' for m in data['Mounts'])
    allowed={str(REPO),'/dev/null',str(ROOT),str(PG),str(REDIS)}
    for mount in data['Mounts']:
        if mount['Type']=='bind':
            assert mount['Source'] in allowed,mount['Source']
            if mount['Source']==str(REPO):assert not mount['RW']
    REPORT['containers'][role]={'name':name,'image':data['Image'],'network':'none',
                               'mounts':data['Mounts'],'no_ports':True}
    return name


def test_container(name):
    args=['--network','none','--read-only','--user',USER,'--cpus','2','--memory','2g','--pids-limit','256',
          '--tmpfs','/tmp:rw,nosuid,size=1g',
          '--mount',f'type=bind,source={REPO},target=/workspace,readonly',
          '--mount','type=bind,source=/dev/null,target=/workspace/.env,readonly',
          '--mount',f'type=bind,source={ROOT},target={ROOT}',
          '--workdir','/workspace']
    env={'PYTHONPATH':'/workspace:/workspace/stockfish-batch-worker:/workspace/stockfish-service:/workspace/tests:/workspace/stockfish-batch-worker/tests',
         'PYTHONDONTWRITEBYTECODE':'1','PYTHONUNBUFFERED':'1',
         'DATABASE_URL':'postgresql+asyncpg://test:test@127.0.0.1:1/test',
         'AUTH_COOKIE_NAME':'test_session','AUTH_GATE_COOKIE_NAME':'test_gate','AUTH_SESSION_TTL_DAYS':'1',
         'AUTH_GATE_TTL_MINUTES':'5','AUTH_COOKIE_SECURE':'false','SUPERADMIN_GATE_CODE':'isolated-test-only',
         'CHESSISM_ANALYSIS_TEST_REDIS_URL':'unix://'+str(REDIS/'redis.sock'),
         'CHESSISM_CANONICAL_TEST_SOCKET':str(PG),'EXPORT_TEST_DATABASE':'1'}
    for k,v in env.items():args+=['--env',k+'='+v]
    args+=['--entrypoint','python','sha256:ba1c705b2daf726ab8c6b4036f945413585fb657590933e2673e0424970721be','-B',str(ROOT/'suite.py'),name]
    container=create(name,args)
    with (ROOT/(name+'.log')).open('w') as log:
        result=subprocess.run(DOCKER+['start','--attach',container],env=ENV,stdout=log,stderr=subprocess.STDOUT,timeout=600)
    actual=int(command(DOCKER+['inspect','--format','{{.State.ExitCode}}',container]).stdout)
    report=json.loads((ROOT/(name+'-results.json')).read_text())
    REPORT['results'][name]=report
    if result.returncode!=0 or actual!=0 or report['tests']!={'foundation': 94}[name] or any(report[k] for k in ('failures','errors','skips')):
        raise RuntimeError(name+' checks failed; review saved test evidence')


def interrupted(*_):
    raise KeyboardInterrupt('Verification interrupted')


def main():
    signal.signal(signal.SIGTERM,interrupted)
    started=time.time()
    ticks=Path('/proc/self/stat').read_text().rsplit(')',1)[1].split()[19]
    update(status='running',pid=os.getpid(),process_start_ticks=ticks,started_at=started,
           finished_at=None,exit_code=None,stage='1/6 — Check frozen source and baseline',current_test=None)
    REPORT['started_at']=started;error=None
    try:
        expected=json.loads((ROOT/'input-sha256.json').read_text())
        # The launcher finishes repository tracking writes before Git scans
        # the worktree. Never race a truncating write with Git's mmap reader.
        update(stage='1/6 — Await completed launch record')
        deadline=time.monotonic()+15
        while not (ROOT/'launch-ready').exists():
            if time.monotonic()>=deadline:
                raise RuntimeError('Launcher did not finish its tracking record')
            time.sleep(.05)
        update(stage='1/6 — Check frozen source and baseline')
        assert snapshot()==expected,'Source changed after handoff'
        original=json.loads((ROOT/'protected-baseline.json').read_text())
        assert all(expected[p]==value for p,value in original.items()),'Protected baseline changed'
        REPORT['unchanged_baseline_files']=len(original)
        for p in json.loads((ROOT/'new-inputs.json').read_text()):
            if p.endswith('.py'):ast.parse((REPO/p).read_text())
        command(['git','-C',str(REPO),'diff','--check'])
        stage('2/6 — Start disposable PostgreSQL and Redis')
        for folder in (PG,REDIS):folder.mkdir(mode=0o777);folder.chmod(0o777)
        pg=create('postgres',['--network','none','--read-only','--user',USER,'--cpus','2','--memory','1g',
            '--pids-limit','128','--tmpfs','/tmp:rw,nosuid,size=1g',
            '--tmpfs','/var/lib/postgresql/data:rw,nosuid,size=1m',
            '--mount',f'type=bind,source={PG},target=/var/run/postgresql',
            '--env','PGDATA=/tmp/pgdata','--env','POSTGRES_USER=test','--env','PGPORT=55432',
            '--env','POSTGRES_DB=chessism_canonical_test','--env','POSTGRES_PASSWORD=isolated-test-only',
            'sha256:9a18aed4ecdd7db9e63f876ace8ef65166d9358ece23893eed8db9b1a7fa0b95','-c','listen_addresses=','-c','port=55432','-c','unix_socket_directories=/var/run/postgresql'])
        redis=create('redis',['--network','none','--read-only','--user',USER,'--memory','128m',
            '--tmpfs','/tmp:rw,nosuid,size=32m','--mount',f'type=bind,source={REDIS},target=/data',
            'sha256:2a51817f79255c8b69f86a974459c2e0359aff81417d80158f2b9e541e6f4b33','redis-server','--port','0','--unixsocket','/data/redis.sock',
            '--unixsocketperm','777','--save','','--appendonly','no'])
        command(DOCKER+['start',pg,redis])
        psql=DOCKER+['exec',pg,'psql','-X','--no-password','-h','/var/run/postgresql',
            '-p','55432','-U','test','-d','chessism_canonical_test','-v','ON_ERROR_STOP=1']
        # pg_isready also succeeds for the entrypoint's temporary bootstrap server.
        # That server is stopped again before exec replaces PID 1 with PostgreSQL.
        with (ROOT/'readiness.log').open('w') as log:
            for _ in range(120):
                process=subprocess.run(DOCKER+['exec',pg,'cat','/proc/1/comm'],
                    capture_output=True,text=True,env=ENV,timeout=5)
                log.write('PID 1: '+process.stdout.strip()+'\n'+process.stderr);log.flush()
                if process.returncode==0 and process.stdout.strip()=='postgres':
                    ready=subprocess.run(psql+['-Atq','-c','SELECT current_database()'],
                        capture_output=True,text=True,env=ENV,timeout=5)
                    log.write(ready.stdout+ready.stderr);log.flush()
                    if ready.returncode==0 and ready.stdout.strip()=='chessism_canonical_test' and (REDIS/'redis.sock').exists():break
                time.sleep(.25)
            else:raise RuntimeError('Final private PostgreSQL server/database did not become ready')
        collation=command(psql+['-c',"SHOW lc_collate; SELECT token FROM unnest(ARRAY['Nf3','c4']) token ORDER BY token; SELECT round(74.975::numeric,2);"]).stdout
        (ROOT/'postgres-semantics.txt').write_text(collation)
        stage('3/6 — 94 canonical schema checks for new CUDA foundation')
        test_container('foundation')
        assert snapshot()==expected,'Source changed during verification'
        REPORT['source_unchanged']=True
        REPORT['passed']=True
    except BaseException as exc:
        error=exc;REPORT['passed']=False;REPORT['error_type']=type(exc).__name__
        (ROOT/'technical-error.txt').write_text(traceback.format_exc())
        REPORT['source_unchanged']=snapshot()==expected
        for role in ('postgres','redis'):
            item=REPORT['containers'].get(role)
            if item:
                logs=subprocess.run(DOCKER+['logs',item['name']],capture_output=True,text=True,env=ENV,timeout=10)
                (ROOT/(role+'-failure.log')).write_text(logs.stdout+logs.stderr)
    finally:
        stage('6/6 — Remove owned disposable test containers')
        cleanup=[]
        for name in reversed(OWNED):
            try:
                data=json.loads(command(DOCKER+['inspect',name]).stdout)[0]
                assert data['Config']['Labels']['chessism.a3.cuda.run']==RUN
                if data['State']['Running']:
                    command(DOCKER+['stop','--time','30',name],timeout=40)
                command(DOCKER+['rm','--volumes',name])
                cleanup.append({'container':name,'removed':True})
            except BaseException:
                cleanup.append({'container':name,'removed':False});REPORT['passed']=False
        REPORT['cleanup']=cleanup;REPORT['finished_at']=time.time()
        REPORT['elapsed_seconds']=REPORT['finished_at']-started
        (ROOT/'results.json').write_text(json.dumps(REPORT,indent=2)+'\n')
        passed=REPORT.get('passed',False)
        update(status='finished' if passed else 'failed',finished_at=REPORT['finished_at'],exit_code=0 if passed else 1,
               stage='A3.2 cuda verification passed — evidence review and local commit pending' if passed else 'Verification stopped — review saved evidence',
               current_test=None,tests_total=None)
    return 0 if REPORT['passed'] else 1


if __name__=='__main__':sys.exit(main())
