"""Structured unittest evidence and live check identity for this disposable run."""
import json
import sys
import time
import unittest
from monitor import ROOT,update

name=sys.argv[1]
modules={'foundation': ['tests.test_cloud_analysis_database', 'tests.test_cloud_auto_sequences_database', 'tests.test_cloud_cancellation_database', 'tests.test_cloud_cleanup_progress_database', 'tests.test_cloud_column_database', 'tests.test_cloud_draft_cache_benchmark_database', 'tests.test_cloud_finalization_database', 'tests.test_cloud_game_drafts_database', 'tests.test_cloud_import_recovery_database', 'tests.test_cloud_incremental_drafts_database', 'tests.test_cloud_input_preparation_database', 'tests.test_cloud_prepared_benchmark_database', 'tests.test_cloud_prepared_selections_database', 'tests.test_cloud_sequences_database', 'tests.test_cloud_upload_progress_database', 'tests.test_cloud_work_units_database']}[name]
assert isinstance(modules, list) and all(isinstance(module, str) for module in modules)
class Progress(unittest.TextTestResult):
    def startTest(self,test):
        super().startTest(test);update(current_test=test.id())
    def stopTest(self,test):
        super().stopTest(test);update(tests_completed=self.testsRun)
suite=unittest.defaultTestLoader.loadTestsFromNames(modules)
update(tests_total=suite.countTestCases(),tests_completed=0)
started=time.time()
result=unittest.TextTestRunner(verbosity=2,resultclass=Progress).run(suite)
report={'suite':name,'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
        'skips':len(result.skipped),'elapsed_seconds':time.time()-started,
        'failure_details':result.failures,'error_details':result.errors,'skip_details':result.skipped,
        'python':sys.version}
for field in ['failure_details','error_details','skip_details']:
    report[field]=[{'test':test.id(),'detail':detail} for test,detail in report[field]]
(ROOT/(name+'-results.json')).write_text(json.dumps(report,indent=2)+'\n')
sys.exit(0 if result.wasSuccessful() and not result.skipped else 1)
