from pathlib import Path
import ast, hashlib, json, subprocess
repo=Path('/home/jon/Desktop/workshop/last_chessism'); old=Path('/tmp/chessism-canonical-a3-cuda-20261118-42'); root=Path('/tmp/chessism-stage-a-final-20261118');root.mkdir(exist_ok=False)
(root/'monitor.py').write_text((old/'monitor.py').read_text().replace('Chessism Stage A3.1 export lifecycle — canonical export lifecycle verification','Chessism Stage A — final baseline comparison'))
s=(old/'runner.py').read_text().replace('A3.2 cuda','Stage A final').replace('A3.2','Stage A final')
s=s.replace("         'CHESSISM_ANALYSIS_TEST_REDIS_URL':'unix://'+str(REDIS/'redis.sock'),\n         'CHESSISM_CANONICAL_TEST_SOCKET':str(PG),'EXPORT_TEST_DATABASE':'1'}", "         }\n    if name=='p1':env['CHESSISM_ANALYSIS_TEST_REDIS_URL']='unix://'+str(REDIS/'redis.sock')")
a=s.index('    if result.returncode!=0');b=s.index('\n\n\ndef interrupted',a)
s=s[:a]+"    REPORT['results'][name]['container_exit_code']=actual\n    assert actual in (0,1) and report['tests']>0, 'Test runner did not finish normally'\n"+s[b:]
a=s.index("        stage('2/6");b=s.index("        redis=create",a)
s=s[:a]+"        stage('2/5 — Start disposable Redis')\n        REDIS.mkdir(mode=0o777);REDIS.chmod(0o777)\n"+s[b:]
a=s.index("        command(DOCKER+['start',pg,redis])");b=s.index("        assert snapshot()==expected,'Source changed during verification'",a)
s=s[:a]+"""        command(DOCKER+['start',redis])
        for _ in range(120):
            if (REDIS/'redis.sock').exists():break
            time.sleep(.1)
        else:raise RuntimeError('Private Redis socket was not ready')
        for name in ('api','worker','p1'):
            stage('Run '+name+' comparison suite')
            test_container(name)
"""+s[b:]
s=s.replace("'6/6 — Remove owned disposable test containers'","'5/5 — Remove owned disposable test containers'")
s=s.replace('verification passed — evidence review and local commit pending','suites recorded — baseline comparison review pending')
(root/'runner.py').write_text(s)
(root/'suite.py').write_text('''"""Full suite evidence; no implicit service connections or spawned reexecution."""
import json,sys,time,unittest
from monitor import ROOT,update

if __name__=='__main__':
    name=sys.argv[1]
    class Progress(unittest.TextTestResult):
        test_ids=[]
        def startTest(self,test):
            super().startTest(test);self.test_ids.append(test.id());update(current_test=test.id())
        def stopTest(self,test):
            super().stopTest(test);update(tests_completed=self.testsRun)
    loader=unittest.TestLoader()
    if name=='api':suite=loader.discover('/workspace/tests',pattern='test*.py')
    elif name=='worker':
        sys.path.insert(0,'/workspace/stockfish-batch-worker')
        sys.path.insert(0,'/workspace/stockfish-batch-worker/tests')
        suite=loader.discover('/workspace/stockfish-batch-worker/tests',pattern='test*.py')
    elif name=='p1':suite=loader.loadTestsFromNames(['test_analysis_failure_selection','test_analysis_failure_jobs','test_analysis_failure_arq','test_analysis_terminal_progress','test_analysis_scheduling','test_analysis_batch_limits'])
    else:raise ValueError(name)
    update(tests_total=suite.countTestCases(),tests_completed=0)
    started=time.time();result=unittest.TextTestRunner(verbosity=2,resultclass=Progress).run(suite)
    report={'suite':name,'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skips':len(result.skipped),'elapsed_seconds':time.time()-started,'python':sys.version,'test_ids':result.test_ids}
    for field,items in [('failure_details',result.failures),('error_details',result.errors),('skip_details',result.skipped)]:report[field]=[{'test':test.id(),'detail':detail} for test,detail in items]
    (ROOT/(name+'-results.json')).write_text(json.dumps(report,indent=2)+'\\n')
    sys.exit(0 if result.wasSuccessful() else 1)
''')
files=subprocess.check_output(['git','ls-files','-co','--exclude-standard'],cwd=repo,text=True).splitlines();files={p for p in files if (repo/p).is_file() and not p.startswith('docs/architecture/evidence/')}
snapshot={p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in sorted(files)}
for name,value in [('input-sha256.json',snapshot),('protected-baseline.json',snapshot),('new-inputs.json',[]),('removed-baseline-inputs.json',[])]: (root/name).write_text(json.dumps(value,indent=2)+'\n')
(root/'launch-ready').touch()
for p in root.glob('*.py'):ast.parse(p.read_text())
print(root)
