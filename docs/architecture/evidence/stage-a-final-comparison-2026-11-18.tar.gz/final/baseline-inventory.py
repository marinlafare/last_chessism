import unittest,json
from pathlib import Path
if __name__=='__main__':
 loader=unittest.TestLoader();suite=loader.discover('/workspace/tests',pattern='test*.py')
 def walk(s):
  for test in s:
   if isinstance(test,unittest.TestSuite):yield from walk(test)
   else:yield test.id()
 ids=list(walk(suite));Path(__file__).with_name('baseline-test-inventory.json').write_text(json.dumps({'tests':len(ids),'test_ids':ids,'loader_errors':loader.errors},indent=2)+'\n')
