from pathlib import Path
import json,os,shutil,subprocess,time
root=Path('/tmp/chessism-stage-a-final-20261118'); repo=Path('/home/jon/Desktop/workshop/last_chessism');d=['docker','--host','unix:///var/run/docker.sock']
# Immutable copy uses dependencies already present in the cached frontend image.
web=root/'web';shutil.copytree(repo/'chessism_web',web,ignore=shutil.ignore_patterns('node_modules','dist','.env','*.log'))
common=['--rm','--pull','never','--network','none','--read-only','--user',f'{os.getuid()}:{os.getgid()}','--cpus','2','--memory','2g','--pids-limit','256','--tmpfs','/tmp:rw,size=512m','--label','chessism.stage-a.final-runtime=true']
checks={
'frontend-cached':common+['--name','chessism-stage-a-final-web','--mount',f'type=bind,source={web},target=/verify','--workdir','/verify','--entrypoint','sh','sha256:f45b84f223fd27a824a0b8ff1c30f5b8529d1a9ed4aae67e0fc92625acfde4d1','-c','ln -s /app/node_modules node_modules; node --test --test-reporter=tap tests/*.test.mjs > tests.log 2>&1; status=$?; /app/node_modules/.bin/vite build > build.log 2>&1; build=$?; echo "test_exit=$status build_exit=$build"; test "$status" -eq 0 && test "$build" -eq 0'],
'worker-supported':common+['--name','chessism-stage-a-final-worker','--mount',f'type=bind,source={repo},target=/workspace,readonly','--mount','type=bind,source=/dev/null,target=/workspace/.env,readonly','--mount',f'type=bind,source={root},target={root}','--workdir','/workspace','--env','PYTHONDONTWRITEBYTECODE=1','--env','PYTHONPATH=/workspace:/workspace/stockfish-batch-worker:/workspace/stockfish-batch-worker/tests','--entrypoint','python','chessism-cloud-controller:latest','-B',str(root/'suite.py'),'worker'],
'cloud-read-supported':common+['--name','chessism-stage-a-final-cloud-read','--mount',f'type=bind,source={repo},target=/workspace,readonly','--mount','type=bind,source=/dev/null,target=/workspace/.env,readonly','--workdir','/workspace','--env','PYTHONDONTWRITEBYTECODE=1','--env','PYTHONPATH=/workspace:/workspace/stockfish-batch-worker:/workspace/stockfish-service','--env','DATABASE_URL=postgresql+asyncpg://test:test@127.0.0.1:1/test','--entrypoint','python','chessism-cloud-controller:latest','-B','-m','unittest','-v','tests.test_cloud_read_recovery']}
# Keep the failed Python3.10 worker result as explicit environment evidence.
(root/'worker-results.json').rename(root/'worker-python310-results.json')
results={}
for name,args in checks.items():
 start=time.time();(root/(name+'-command.json')).write_text(json.dumps(d+['run',*args],indent=2))
 with (root/(name+'.log')).open('w') as log:r=subprocess.run(d+['run',*args],stdout=log,stderr=subprocess.STDOUT,timeout=180)
 results[name]={'exit_code':r.returncode,'elapsed_seconds':time.time()-start}
 print(name,results[name],flush=True)
(root/'runtime-checks.json').write_text(json.dumps(results,indent=2)+'\n')
