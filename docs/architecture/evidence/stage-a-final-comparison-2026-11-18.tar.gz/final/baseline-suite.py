import sys,unittest,json
from pathlib import Path
if __name__=='__main__':
 names=['test_cloud_auto_sequences.AutoSequenceTests.test_split_total_instead_of_multiplying_or_balancing','test_cloud_analysis.ControllerGateTests.test_real_cleanup_writes_tmp_plan_and_can_recreate_it_after_restart','test_pipeline_helpers.AnalysisJobsApiTests.test_analysis_jobs_lists_running_and_queued_from_server_queue']
 result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromNames(names))
 report={'tests':result.testsRun,'failures':[{'test':t.id(),'detail':d} for t,d in result.failures],'errors':[{'test':t.id(),'detail':d} for t,d in result.errors],'skips':[{'test':t.id(),'detail':d} for t,d in result.skipped]}
 Path(__file__).with_name('baseline-results.json').write_text(json.dumps(report,indent=2)+'\n')
