"""Full suite evidence; no implicit service connections or spawned reexecution."""
import json,sys,time,unittest
from monitor import ROOT,update

if __name__=='__main__':
    name=sys.argv[1]
    class Progress(unittest.TextTestResult):
        test_ids=[]
        def startTest(self,test):
            super().startTest(test);self.test_ids.append(test.id());update(current_test=test.id())
        def stopTest(self,test):
            super().stopTest(test);update(tests_completed=self.testsRun)
    loader=unittest.TestLoader()
    if name=='api':suite=loader.discover('/workspace/tests',pattern='test*.py')
    elif name=='worker':
        sys.path.insert(0,'/workspace/stockfish-batch-worker')
        sys.path.insert(0,'/workspace/stockfish-batch-worker/tests')
        suite=loader.discover('/workspace/stockfish-batch-worker/tests',pattern='test*.py')
    elif name=='p1':suite=loader.loadTestsFromNames(['test_analysis_failure_selection','test_analysis_failure_jobs','test_analysis_failure_arq','test_analysis_terminal_progress','test_analysis_scheduling','test_analysis_batch_limits'])
    elif name=='ports':suite=loader.loadTestsFromNames(['test_algorithm_builder.BuilderApiTests','test_cuda_player_validation.WiringTests','test_coverage_optimization','test_summary_algorithms','test_matrix_storage.MatrixBackupTests.test_manual_backup_manifest_includes_matrices','test_pipeline_helpers.PlayerDeletionSafetyTests','test_fen_identity_writes'])
    else:raise ValueError(name)
    update(tests_total=suite.countTestCases(),tests_completed=0)
    started=time.time();result=unittest.TextTestRunner(verbosity=2,resultclass=Progress).run(suite)
    report={'suite':name,'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skips':len(result.skipped),'elapsed_seconds':time.time()-started,'python':sys.version,'test_ids':result.test_ids}
    for field,items in [('failure_details',result.failures),('error_details',result.errors),('skip_details',result.skipped)]:report[field]=[{'test':test.id(),'detail':detail} for test,detail in items]
    (ROOT/(name+'-results.json')).write_text(json.dumps(report,indent=2)+'\n')
    sys.exit(0 if result.wasSuccessful() else 1)
