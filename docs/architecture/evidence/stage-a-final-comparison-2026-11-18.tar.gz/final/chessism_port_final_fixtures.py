from pathlib import Path
import ast,json
p=Path('tests/test_coverage_optimization.py');s=p.read_text().replace('abs(f.score)','abs(f.score::bigint)');p.write_text(s)
p=Path('tests/test_summary_algorithms.py');s=p.read_text().replace('gfa.move_color=gp.color','gfa.is_white=gp.is_white').replace("query.index('LEFT JOIN fen')","query.index('LEFT JOIN public.fen')");p.write_text(s)
p=Path('tests/test_algorithm_builder.py');s=p.read_text().replace('factory.return_value.__aenter__.return_value = AsyncMock()','factory.return_value = AsyncMock()');p.write_text(s)
p=Path('tests/test_cuda_player_validation.py');s=p.read_text().replace('session = AsyncMock(); session.begin = MagicMock(); session.get.return_value = row','session = AsyncMock(); session.get.return_value = row').replace('factory = MagicMock(); factory.return_value.__aenter__.return_value = session','factory = MagicMock(return_value=session)');p.write_text(s)
p=Path('tests/test_pipeline_helpers.py');s=p.read_text();a=s.index('class PlayerDeletionSafetyTests');b=s.index('class StockfishSerializationTests',a);t=s[a:b]
a1=t.index('    @staticmethod');b1=t.index('    async def test_preview',a1);t=t[:a1]+t[b1:]
t=t.replace('return_value=self._session_context(session)','return_value=session')
t=t.replace('session.execute.side_effect = [player_result, counts_result]','session.execute.side_effect = [MagicMock(), MagicMock(), player_result, counts_result]')
t=t.replace('classification_sql = str(session.execute.await_args_list[1].args[0])','classification_sql = str(session.execute.await_args_list[3].args[0])')
t=t.replace('links_result.scalars.return_value.all.return_value = [101, 102]','links_result.scalars.return_value = [101, 102]')
t=t.replace('            update_result,\n            update_result,\n            update_result,','            update_result,')
t=t.replace('"UPDATE fen current_fen"','"UPDATE fen SET n_games"')
t=t.replace('        self.assertIn("DELETE FROM game_fen_association", sql)\n        self.assertIn("DELETE FROM moves", sql)','        # Canonical foreign keys cascade game-owned occurrences and moves;\n        # real-PG deletion tests verify those dependent rows disappear.\n        self.assertIn("FOR UPDATE OF g,opponent SKIP LOCKED", sql)')
t=t.replace('        remaining_result = MagicMock()\n        remaining_result.scalar.return_value = 0\n','')
t=t.replace('        session.execute.side_effect = [\n            remaining_result,','        session.scalar.side_effect = [17, False]\n        session.execute.side_effect = [')
t=t.replace('"joined = 0"','"joined=0"').replace('"deleted_at = CURRENT_TIMESTAMP"','"deleted_at=CURRENT_TIMESTAMP"')
s=s[:a]+t+s[b:];p.write_text(s)
p=Path('tests/test_matrix_storage.py');s=p.read_text();s=s.replace("                patch('chessism_api.database.postgresql.fen_identity.schema_version', return_value='numeric_v2'),\n                patch('chessism_api.database.postgresql.fen_reference_identity.schema_version', return_value='numeric_v1'),", "                patch('chessism_api.database.postgresql.transactions.driver_connection', AsyncMock()),\n                patch('chessism_api.database.postgresql.canonical.backup.describe', AsyncMock(return_value=canonical_contract)),")
s=s.replace('            calls = []\n            async def save_matrices',"            canonical_contract = {'contract':'chessism-canonical-v1','version':17,\n                                  'ddl_sha256':'a'*64,'catalog_sha256':'b'*64}\n            calls = []\n            async def save_matrices")
s=s.replace('self.assertEqual(manifest["schema_version"], 6)','self.assertEqual(manifest["schema_version"], 9)').replace("self.assertEqual(manifest[\"fen_reference_version\"], 'numeric_v1')","self.assertEqual(manifest[\"fen_reference_version\"], 'canonical_v1')\n            self.assertEqual(manifest[\"canonical_schema\"], canonical_contract)")
p.write_text(s)
p=Path('tests/test_fen_identity_writes.py');s=p.read_text();tree=ast.parse(s);cls=next(n for n in tree.body if isinstance(n,ast.ClassDef));removed=[]
for method in reversed(cls.body[:2]):
 removed.append(method.name);lines=s.splitlines(keepends=True);s=''.join(lines[:method.lineno-1]+lines[method.end_lineno:])
s=s.replace('from chessism_api.operations.fen_results import resolve_fen_ids, replace_fen_continuations\n','');p.write_text(s)
p=Path('docs/architecture/storage-retirement-tests.json');m=json.loads(p.read_text());m['final_gate_test_ports']={'reason':'Broad suite found mocks still returning context managers, retired SQL identifiers, and format6 backup assumptions. Port to caller-owned transactions, native keys and approved format9; behavior assertions retained.','retired_helper_cases':removed,'replacement_cases':['tests.check_canonical_evaluations_postgres.CanonicalEvaluationTests.test_whole_batch_validation_and_missing_identity_preserve_prior_commits','tests.check_canonical_evaluations_postgres.CanonicalEvaluationTests.test_bounded_statements_include_typed_all_null_columns','tests.check_canonical_evaluations_postgres.CanonicalEvaluationTests.test_scores_alternatives_and_totals_commit_together']};p.write_text(json.dumps(m,indent=2)+'\n')
