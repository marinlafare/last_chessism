from pathlib import Path
import json,re,hashlib,ast
from collections import Counter
root=Path('/tmp/chessism-stage-a-final-20261118');repo=Path('/home/jon/Desktop/workshop/last_chessism');m=json.loads((repo/'refactor-manifest.json').read_text())
def read(n):return json.loads((root/n).read_text())
a=read('api-results.json');ports=read('ports-results.json');w=read('worker-results.json');p1=read('p1-results.json');b=read('baseline-results.json');inventory=read('baseline-test-inventory.json')
assert len(inventory['loader_errors'])==1 and "No module named 'google'" in inventory['loader_errors'][0]
cloud=['test_cloud_read_recovery.ReadRecoveryTests.'+n.name for n in next(n for n in ast.parse((repo/'tests/test_cloud_read_recovery.py').read_text()).body if isinstance(n,ast.ClassDef)).body if isinstance(n,ast.FunctionDef) and n.name.startswith('test')]
assert len(cloud)==4 and 'Ran 4 tests' in (root/'cloud-read-supported.log').read_text() and (root/'cloud-read-supported.log').read_text().rstrip().endswith('OK')
baseids=[i for i in inventory['test_ids'] if i!='unittest.loader._FailedTest.test_cloud_read_recovery']+cloud
assert len(baseids)==1450,len(baseids)
ids=[i for i in a['test_ids'] if i not in ('unittest.loader._FailedTest.test_cloud_read_recovery','unittest.loader._FailedTest.test_fen_identity_writes')]+cloud+['test_fen_identity_writes.IdentityTests.test_startup_refuses_legacy_and_partial_schema_without_writing']
expected={i['test']:i['detail'].splitlines()[-1] for field in ('failures','errors') for i in b[field]}
failures=[];fixed=[]
assert not any(ports[k] for k in ('failures','errors','skips'))
for field in ('failure_details','error_details'):
 for item in a[field]:
  ident=item['test']
  if ident in expected:
   assert item['detail'].splitlines()[-1]==expected[ident];failures.append(item)
  elif ident in ports['test_ids'] or ident.startswith('unittest.loader._FailedTest.'):
   fixed.append(item)
  else:raise AssertionError('Unverified failure '+ident)
assert len(failures)==3
new=Counter(ids)-Counter(baseids);retired=Counter(baseids)-Counter(ids)
# Hash all files frozen at the broad run; only the explicitly ported tests and
# A4 maintenance launcher/tracking files may differ afterwards.
snapshot=read('input-sha256.json');changed=[p for p,h in snapshot.items() if not (repo/p).exists() or hashlib.sha256((repo/p).read_bytes()).hexdigest()!=h]
allowed={'docker-compose.migration.yml','docs/architecture/storage-retirement-tests.json','tests/test_algorithm_builder.py','tests/test_coverage_optimization.py','tests/test_cuda_player_validation.py','tests/test_fen_identity_writes.py','tests/test_matrix_storage.py','tests/test_pipeline_helpers.py','tests/test_summary_algorithms.py'}
assert set(changed)<=allowed,changed
# All frontend source used for the full corrected test/build copy is current.
web={p:h for p,h in snapshot.items() if p.startswith('chessism_web/')}
for path,digest in web.items():
 copy=root/'web'/Path(path).relative_to('chessism_web')
 assert copy.exists() and hashlib.sha256(copy.read_bytes()).hexdigest()==digest,path
old=m['final_review_corrections']['frontend_baseline']['failure_details']
s=(root/'web/tests-corrected.log').read_text();blocks=re.findall(r'^not ok .*?^  \.\.\.',s,re.M|re.S)
nav=re.findall(r'^not ok .*?^  \.\.\.',(root/'frontend-navigation.log').read_text(),re.M|re.S);assert len(nav)==1;blocks[-1]=nav[0]
def norm(s):
 s=re.sub(r'^not ok \d+ - ','not ok - ',s,flags=re.M);s=re.sub(r'^  duration_ms:.*\n','',s,flags=re.M);return s.replace('/tmp/chessism-source/chessism_web/','/web/').replace('/verify/','/web/').replace('/workspace/chessism_web/','/web/').strip()
assert len(blocks)==4
for before,after in zip(old,blocks):assert norm(before['details'])==norm(after),before['test']
assert '# tests 346' in s and '# skipped 0' in s and '# cancelled 0' in s
assert 'Page-boundary check passed' in (root/'web/build-corrected.log').read_text() and 'Source-size check passed' in (root/'web/build-corrected.log').read_text() and 'built in' in (root/'web/build-corrected.log').read_text()
assert (w['tests'],w['failures'],w['errors'],w['skips'])==(287,0,0,7)
assert {i['test'] for i in w['skip_details']}==set(m['verification']['baseline_results']['worker']['skip_ids'])
assert (p1['tests'],p1['failures'],p1['errors'],p1['skips'])==(68,0,0,0)
report={'status':'verified_with_preexisting_debt','accepted':False,'baseline_commit':'0fde829d9477b3f73714b52e820a67bad49dad77',
 'api':{'baseline_tests':1450,'baseline_failures':3,'baseline_errors':10,'baseline_skips':276,'broad_initial_tests':a['tests'],'effective_tests':len(ids),'failures':1,'errors':2,'skips':a['skips'],'composition':'One broad API run plus 37 affected fixture checks and four cloud SDK checks. Two failed import placeholders replaced by actual tests; no second full API run.','remaining_debt':failures,'corrected_or_environment_errors':fixed,'new_test_identities':dict(new),'retired_test_identities':dict(retired),'test_ids':ids},
 'worker':{k:w[k] for k in ('tests','failures','errors','skips','python','elapsed_seconds')},'p1':{k:p1[k] for k in ('tests','failures','errors','skips','elapsed_seconds')},
 'frontend':{'tests':346,'passed':342,'failures':4,'errors':0,'skips':0,'cancelled':0,'assertion_details_match_baseline':True,'failure_details':blocks,'architecture_source_size_build':'passed'},
 'source_integrity':{'broad_run_unchanged':read('results.json')['source_unchanged'],'post_run_changes':changed,'application_code_changed_since_broad_run':False,'frontend_input_files_match':len(web)},
 'environment_corrections':['Worker requires Python3.11; initial API-image worker run is invalid, supported image passes unchanged 287 checks.','Cloud SDK read-recovery module ran in cached controller runtime: four pass.','Frontend lockfile installed only in disposable copy, no scripts; full fixture copy missing parent navigation resource corrected by rerunning that file in read-only repository layout.','No dependency requirements or test assertions weakened.'],
 'skip_notes':'Offline discovery deliberately omits opt-in PG/Redis/GPU. P1 Redis cases pass separately (68); added FEN backup and matrix cases pass in archived isolated PG gates. Historical migration/profile checks explicitly retired. Existing unrelated opt-in test skips remain; no new behavior left unverified merely by skipping.',
 'resources':'All owned containers removed; no live services/data/recovery checkpoint accessed'}
(root/'comparison.json').write_text(json.dumps(report,indent=2)+'\n')
print('baseline',len(baseids),'effective',len(ids),'new',sum(new.values()),'retired',sum(retired.values()),'application unchanged',True)
print('comparison complete')
