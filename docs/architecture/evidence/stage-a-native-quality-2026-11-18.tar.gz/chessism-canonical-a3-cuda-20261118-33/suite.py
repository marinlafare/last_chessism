"""Structured unittest evidence and live check identity for this disposable run."""
import json
import sys
import time
import unittest
from monitor import ROOT,update

name=sys.argv[1]
modules={'foundation': ['tests.check_canonical_quality_postgres.CanonicalQualityTests.test_range_daily_calendar_and_position_contracts_keep_native_sides', 'tests.check_canonical_quality_postgres.CanonicalQualityTests.test_insight_windows_do_not_mix_self_play_sides_and_patterns_keep_counts', 'tests.check_canonical_quality_postgres.CanonicalQualityTests.test_missing_engine_results_refresh_only_after_read_transaction_closes', 'tests.check_canonical_quality_postgres.CanonicalQualityTests.test_unknown_player_empty_selection_and_database_errors_are_not_success', 'tests.test_pipeline_helpers.PlayerHeroAnalyticsTests.test_game_explorer_validates_and_labels_chart_bins', 'tests.test_pipeline_helpers.PlayerHeroAnalyticsTests.test_game_score_formats_board_positions_clocks_and_mover_accuracy', 'tests.test_pipeline_helpers.PlayerHeroAnalyticsTests.test_daily_cp_points_have_only_date_and_summed_game_cp', 'tests.test_pipeline_helpers.PlayerHeroAnalyticsTests.test_daily_efficiency_points_have_only_date_and_mean_efficiency', 'tests.test_pipeline_helpers.PlayerHeroAnalyticsTests.test_game_player_engine_summary_keeps_only_player_game_score_fields', 'tests.test_pipeline_helpers.PlayerHeroAnalyticsTests.test_lichess_blunder_uses_winning_chance_loss_not_fixed_cp_loss', 'tests.test_pipeline_helpers.PlayerHeroAnalyticsTests.test_lichess_winning_chances_are_symmetric_and_cap_at_1000_cp', 'tests.test_pipeline_helpers.PlayerHeroAnalyticsTests.test_lichess_move_accuracy_is_player_oriented_and_bounded', 'tests.test_pipeline_helpers.PlayerHeroAnalyticsTests.test_efficiency_modes_accept_exact_mode_combinations', 'tests.test_pipeline_helpers.PlayerHeroAnalyticsTests.test_lichess_blunder_copies_forced_mate_boundaries', 'tests.test_pipeline_helpers.PlayerHeroAnalyticsTests.test_activity_rows_can_be_aggregated_after_grouping_by_mode', 'tests.test_pipeline_helpers.PlayerHeroAnalyticsTests.test_measure_rows_can_be_aggregated_after_grouping_by_mode', 'tests.test_pipeline_helpers.PlayerHeroAnalyticsTests.test_measure_coverage_sums_mode_rows', 'tests.test_pipeline_helpers.PlayerHeroAnalyticsTests.test_country_with_even_zone_count_uses_two_center_zones', 'tests.test_pipeline_helpers.PlayerHeroAnalyticsTests.test_location_can_resolve_one_country_zone', 'tests.test_pipeline_helpers.PlayerHeroAnalyticsTests.test_black_player_scores_and_signed_cp_change_are_inverted', 'tests.test_pipeline_helpers.PlayerHeroAnalyticsTests.test_empty_measure_bucket_uses_null_cp_values', 'tests.test_pipeline_helpers.PlayerAnalyticsTests.test_filters_are_normalized_and_form_a_stable_cache_key', 'tests.test_pipeline_helpers.PlayerAnalyticsTests.test_invalid_date_range_is_rejected_before_querying', 'tests.test_pipeline_helpers.PlayerAnalyticsTests.test_query_returns_compact_json_with_scope_metadata', 'tests.test_pipeline_helpers.PlayerAnalyticsTests.test_queries_are_aggregated_and_outputs_are_bounded', 'tests.check_canonical_activity_postgres']}[name]
assert isinstance(modules, list) and all(isinstance(module, str) for module in modules)
class Progress(unittest.TextTestResult):
    def startTest(self,test):
        super().startTest(test);update(current_test=test.id())
    def stopTest(self,test):
        super().stopTest(test);update(tests_completed=self.testsRun)
suite=unittest.defaultTestLoader.loadTestsFromNames(modules)
update(tests_total=suite.countTestCases(),tests_completed=0)
started=time.time()
result=unittest.TextTestRunner(verbosity=2,resultclass=Progress).run(suite)
report={'suite':name,'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
        'skips':len(result.skipped),'elapsed_seconds':time.time()-started,
        'failure_details':result.failures,'error_details':result.errors,'skip_details':result.skipped,
        'python':sys.version}
for field in ['failure_details','error_details','skip_details']:
    report[field]=[{'test':test.id(),'detail':detail} for test,detail in report[field]]
(ROOT/(name+'-results.json')).write_text(json.dumps(report,indent=2)+'\n')
sys.exit(0 if result.wasSuccessful() and not result.skipped else 1)
