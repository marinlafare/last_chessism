"""Structured unittest evidence and live check identity for this disposable run."""
import json
import sys
import time
import unittest
from monitor import ROOT,update

name=sys.argv[1]
modules={'foundation': ['tests.check_canonical_auxiliary_research_postgres.CanonicalAuxiliaryResearchTests.test_coefficient_selection_uses_unique_games_weights_and_exact_scores', 'tests.check_canonical_auxiliary_research_postgres.CanonicalAuxiliaryResearchTests.test_coefficient_api_job_artifact_and_research_decision_round_trip', 'tests.check_canonical_auxiliary_research_postgres.CanonicalAuxiliaryResearchTests.test_coefficient_query_failure_and_cancellation_propagate', 'tests.check_canonical_auxiliary_research_postgres.CanonicalAuxiliaryResearchTests.test_coefficient_schema_enforces_existing_states_decisions_and_owner_reference', 'tests.check_canonical_auxiliary_research_postgres.CanonicalAuxiliaryResearchTests.test_salience_snapshot_reads_native_metadata_positions_and_moves_without_writes', 'tests.check_canonical_auxiliary_research_postgres.CanonicalAuxiliaryResearchTests.test_salience_preserves_report_limitations_and_hides_incomplete_files', 'tests.check_canonical_runtime_tools_postgres.RuntimeToolsTests.test_full_cohort_launcher_preserves_snapshots_and_native_sides', 'tests.check_canonical_runtime_tools_postgres.RuntimeToolsTests.test_cloud_claim_copy_requires_transaction_and_rolls_back_conflicts', 'tests.check_canonical_runtime_tools_postgres.RuntimeToolsTests.test_rerun_comparison_uses_native_sides_and_detects_real_differences', 'tests.check_canonical_runtime_tools_postgres.RuntimeToolsTests.test_model_status_and_rollback_keep_explicit_transaction_boundary', 'tests.test_coefficient_research', 'tests.test_salience_comparison', 'tests.check_canonical_schema_postgres']}[name]
assert isinstance(modules, list) and all(isinstance(module, str) for module in modules)
class Progress(unittest.TextTestResult):
    def startTest(self,test):
        super().startTest(test);update(current_test=test.id())
    def stopTest(self,test):
        super().stopTest(test);update(tests_completed=self.testsRun)
suite=unittest.defaultTestLoader.loadTestsFromNames(modules)
update(tests_total=suite.countTestCases(),tests_completed=0)
started=time.time()
result=unittest.TextTestRunner(verbosity=2,resultclass=Progress).run(suite)
report={'suite':name,'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
        'skips':len(result.skipped),'elapsed_seconds':time.time()-started,
        'failure_details':result.failures,'error_details':result.errors,'skip_details':result.skipped,
        'python':sys.version}
for field in ['failure_details','error_details','skip_details']:
    report[field]=[{'test':test.id(),'detail':detail} for test,detail in report[field]]
(ROOT/(name+'-results.json')).write_text(json.dumps(report,indent=2)+'\n')
sys.exit(0 if result.wasSuccessful() and not result.skipped else 1)
