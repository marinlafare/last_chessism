"""Temporary Chessism A2.3 analysis selection viewer; Ctrl+C stops only the viewer."""
from pathlib import Path
import datetime as dt
import json
import os
import sys
import time

ROOT = Path(__file__).resolve().parent
STATE = ROOT/'status.json'


def update(**changes):
    state = json.loads(STATE.read_text()) if STATE.exists() else {}
    state.update(changes,updated_at=time.time())
    temporary = ROOT/f'status-{os.getpid()}.tmp'
    temporary.write_text(json.dumps(state,indent=2)+'\n')
    temporary.replace(STATE)


def stamp(value):
    return dt.datetime.fromtimestamp(value).astimezone().strftime('%Y-%m-%d %H:%M:%S %Z')


def display():
    while True:
        now = time.time()
        lines = ['Chessism Stage A2.3 analysis selection — canonical import verification',
                 'Refresh: every 120 seconds. Ctrl+C stops this viewer only.','']
        if STATE.exists():
            s=json.loads(STATE.read_text()); status=s.get('status','starting')
            if not s.get('finished_at') and s.get('pid'):
                try:
                    fields=Path(f"/proc/{s['pid']}/stat").read_text().rsplit(')',1)[1].split()
                    alive=fields[0]!='Z' and fields[19]==s['process_start_ticks']
                except (FileNotFoundError,ProcessLookupError):
                    alive=False
                if not alive: status='runner stopped unexpectedly — evidence needs review'
            elapsed=int((s.get('finished_at') or now)-s['started_at'])
            lines += [f"Supervisor PID: {s.get('pid','starting')}",f'Checked: {stamp(now)}',
                      f"Started: {stamp(s['started_at'])}",f'Elapsed: {dt.timedelta(seconds=max(0,elapsed))}',
                      f'Status: {status}',f"Stage: {s.get('stage','starting')}",
                      'Estimated finish: unavailable for this new verification workload']
            if s.get('current_test'): lines.append('Check: '+s['current_test'])
            if s.get('tests_total') is not None:
                lines.append(f"Current suite: {s.get('tests_completed',0)}/{s['tests_total']} checks completed")
            if s.get('finished_at'):
                lines += [f"Finished: {stamp(s['finished_at'])}",f"Exit code: {s.get('exit_code','unknown')}",
                          'Verification has ended. This viewer stays open until Ctrl+C.']
        else: lines.append('Waiting for verification startup.')
        sys.stdout.write('\x1b[2J\x1b[H'+'\n'.join(lines)+'\n');sys.stdout.flush()
        time.sleep(120)


if __name__=='__main__':
    try: display()
    except KeyboardInterrupt: print('Viewer closed; verification is unaffected.')
