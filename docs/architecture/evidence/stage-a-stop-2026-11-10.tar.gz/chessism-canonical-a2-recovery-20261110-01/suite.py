"""Structured unittest evidence and live check identity for this disposable run."""
import json
import sys
import time
import unittest
from monitor import ROOT,update

name=sys.argv[1]
modules={
 'foundation':['tests.test_canonical_schema','tests.check_canonical_schema_postgres',
               'tests.check_canonical_imports_postgres','tests.check_canonical_ingestion_postgres',
               'tests.check_canonical_fens_postgres','tests.check_canonical_selection_postgres',
               'tests.check_canonical_evaluations_postgres','tests.check_canonical_tablebase_postgres',
               'tests.check_canonical_recovery_postgres'],
 'workflow':['tests.test_ingestion_transactions','tests.test_evaluation_contract','tests.test_cloud_game_queue'],
 'p1':['test_analysis_failure_selection','test_analysis_failure_jobs','test_analysis_failure_arq',
       'test_analysis_terminal_progress','test_analysis_scheduling','test_analysis_batch_limits'],
}[name]
class Progress(unittest.TextTestResult):
    def startTest(self,test):
        super().startTest(test);update(current_test=test.id())
    def stopTest(self,test):
        super().stopTest(test);update(tests_completed=self.testsRun)
suite=unittest.defaultTestLoader.loadTestsFromNames(modules)
update(tests_total=suite.countTestCases(),tests_completed=0)
started=time.time()
result=unittest.TextTestRunner(verbosity=2,resultclass=Progress).run(suite)
report={'suite':name,'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
        'skips':len(result.skipped),'elapsed_seconds':time.time()-started,
        'failure_details':result.failures,'error_details':result.errors,'skip_details':result.skipped,
        'python':sys.version}
for field in ['failure_details','error_details','skip_details']:
    report[field]=[{'test':test.id(),'detail':detail} for test,detail in report[field]]
(ROOT/(name+'-results.json')).write_text(json.dumps(report,indent=2)+'\n')
sys.exit(0 if result.wasSuccessful() and not result.skipped else 1)
