"""Pure fixture contract check; no database, engine, storage or cloud access."""
import ast
import json
import sys
from pathlib import Path
root=Path(__file__).resolve().parent
repo=Path('/workspace')
sys.path[:0]=['/test-deps',str(repo/'stockfish-batch-worker'),str(repo)]
import chess
from stockfish_batch.checkpoints import BatchCheckpoints,make_contract,encode
from stockfish_batch.config import Config
from tests.canonical_schema_fixture import FENS
source=ast.parse((repo/'tests/check_canonical_evaluations_postgres.py').read_text())
helper=next(n for n in source.body if isinstance(n,ast.FunctionDef) and n.name=='cloud_result')
namespace={'chess':chess}
exec(compile(ast.Module(body=[helper],type_ignores=[]),'<actual fixture helper>','exec'),namespace)
checks=[]
for task in (False,True):
    groups=[[{'id':str(i),'fen':fen}] for i,fen in enumerate(FENS[:2])] if task else [[{'id':str(i),'fen':fen} for i,fen in enumerate(FENS[:2])]]
    for positions in groups:
        config=Config(input='synthetic-input',output='synthetic-output',upload_mode='background',batch_size=500,compact_results=True)
        contract=make_contract(b''.join(encode(p) for p in positions),positions,config,'a'*64)
        checkpoint=BatchCheckpoints(None,'',contract,positions,500)
        records=[checkpoint.prepare(p,namespace['cloud_result'](p,contract['settings']['multipv'],int(p['id'])),1) for p in positions]
        verified=checkpoint.validate_batch({'fingerprint':contract['fingerprint'],'records':records},0)
        assert set(verified)=={p['id'] for p in positions}
        assert all(len(r['engine_result']['analysis'])==4 for r in records)
        checks.append({'task':task,'positions':len(positions),'passed':True})
report={'passed':True,'validated_records':sum(c['positions'] for c in checks),'checks':checks,'production_access':False}
(root/'fixture-preflight.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
