from pathlib import Path
import shutil, hashlib, json
root=Path('/home/jon/Desktop/workshop/last_chessism')
target=Path('/tmp/chessism-stage-c-corrections-20261119/project')
for name in ['chessism_web/src','chessism_web/tests','chessism_web/scripts','chessism_web/public']:
 shutil.copytree(root/name,target/name,dirs_exist_ok=True)
for p in (root/'chessism_web').iterdir():
 if p.is_file() and not p.name.startswith('.env'): shutil.copy2(p,target/'chessism_web'/p.name)
(target/'chessism_api').mkdir(exist_ok=True)
for p in (root/'chessism_api').glob('appearance*.json'): shutil.copy2(p,target/'chessism_api'/p.name)
hashes={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for folder in ['chessism_web/src','chessism_web/tests','chessism_web/scripts','chessism_web/public'] for p in (root/folder).rglob('*') if p.is_file()}
Path('/tmp/chessism-stage-c-corrections-20261119/evidence/current-hashes.json').write_text(json.dumps(hashes,indent=2,sort_keys=True))
