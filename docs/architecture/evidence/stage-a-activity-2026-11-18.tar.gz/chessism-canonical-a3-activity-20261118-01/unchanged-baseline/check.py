import json,sys,unittest
from pathlib import Path
root=Path(__file__).resolve().parent
suite=unittest.defaultTestLoader.loadTestsFromName('tests.test_player_time_result_filters')
result=unittest.TextTestRunner(verbosity=2).run(suite)
report=dict(tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),skips=len(result.skipped),
 error_details=[dict(test=t.id(),detail=d) for t,d in result.errors],
 failure_details=[dict(test=t.id(),detail=d) for t,d in result.failures],
 skip_details=[dict(test=t.id(),detail=d) for t,d in result.skipped],python=sys.version)
(root/'results.json').write_text(json.dumps(report,indent=2)+'\n')
sys.exit(0 if result.wasSuccessful() else 1)
