"""Structured unittest evidence and live check identity for this disposable run."""
import json
import sys
import time
import unittest
from monitor import ROOT,update

name=sys.argv[1]
modules={'foundation': ['tests.test_persistence_contracts', 'tests.test_player_score_distribution', 'tests.test_fen_batch_coordination', 'tests.test_matrix_constructor', 'tests.test_matrix_move_scores', 'tests.test_accuracy_matrix', 'tests.test_complete_move_matrix', 'tests.test_matrix_definitions', 'tests.test_matrix_cleanup', 'tests.check_canonical_matrices_postgres.CanonicalMatrixTests.test_every_matrix_catalog_column_runs_on_canonical_tables', 'tests.check_canonical_matrices_postgres.CanonicalMatrixTests.test_filters_dates_modes_sides_and_empty_game_scope', 'tests.check_canonical_matrices_postgres.CanonicalMatrixTests.test_integer_extrema_and_unknown_source_keep_perspective_without_overflow', 'tests.check_canonical_matrices_postgres.CanonicalMatrixTests.test_move_scores_complete_selection_and_dynamic_preview_preserve_keys', 'tests.check_canonical_matrices_postgres.CanonicalMatrixTests.test_estimate_and_preview_use_guarded_native_queries_and_bound_limits', 'tests.check_canonical_matrices_postgres.CanonicalMatrixTests.test_cancelled_preview_closes_its_read_transaction', 'tests.check_canonical_recovery_postgres.CanonicalRecoveryTests.test_version_repeat_and_empty_operation_preserve_queue_and_catalog']}[name]
assert isinstance(modules, list) and all(isinstance(module, str) for module in modules)
class Progress(unittest.TextTestResult):
    def startTest(self,test):
        super().startTest(test);update(current_test=test.id())
    def stopTest(self,test):
        super().stopTest(test);update(tests_completed=self.testsRun)
suite=unittest.defaultTestLoader.loadTestsFromNames(modules)
update(tests_total=suite.countTestCases(),tests_completed=0)
started=time.time()
result=unittest.TextTestRunner(verbosity=2,resultclass=Progress).run(suite)
report={'suite':name,'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
        'skips':len(result.skipped),'elapsed_seconds':time.time()-started,
        'failure_details':result.failures,'error_details':result.errors,'skip_details':result.skipped,
        'python':sys.version}
for field in ['failure_details','error_details','skip_details']:
    report[field]=[{'test':test.id(),'detail':detail} for test,detail in report[field]]
(ROOT/(name+'-results.json')).write_text(json.dumps(report,indent=2)+'\n')
sys.exit(0 if result.wasSuccessful() and not result.skipped else 1)
