import ast,hashlib,json,re,subprocess
from pathlib import Path
root=Path('/home/jon/Desktop/workshop/last_chessism');base=Path('/tmp/chessism-stage-c-20261119');e=base/'evidence'
b=(e/'frontend-baseline22.tap').read_text();g=(e/'frontend-final22.tap').read_text()
def failures(text):
 found={}
 for section in text.split('# Subtest: ')[1:]:
  if not re.search(r'^not ok ',section,re.M):continue
  name=section.splitlines()[0]
  block=section[section.index('  ---'):section.index('  ...')]
  found[name]=re.sub(r'\n  duration_ms:.*','',block)
 return found
bf,gf=failures(b),failures(g)
assert bf==gf, ('Changed failure details',bf.keys(),gf.keys())
bi=re.findall(r'^# Subtest: (.*)$',b,re.M);gi=re.findall(r'^# Subtest: (.*)$',g,re.M)
assert set(bi)<=set(gi)
bb=json.loads((e/'baseline-ingestion-results.json').read_text());bg=json.loads((e/'ingestion-final-results.json').read_text())
assert not bg['failures'] and not bg['errors'] and not bg['skipped']
assert set(bb['identities']) <= set(bg['identities'])
source_hashes=json.loads((e/'current-hashes.json').read_text())
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==v for p,v in source_hashes.items())
protected=['chessism_api/database','chessism_api/operations/analysis.py','chessism_api/operations/engine_client.py','chessism_api/operations/cloud_analysis','stockfish-service','stockfish-batch-worker','chessism_api/routers/jobs.py','chessism_api/routers/games.py','worker.py']
assert not subprocess.check_output(['git','diff','5c037d8','--',*protected],cwd=root)
p='chessism_api/operations/ingestion_pipeline/game_importer.py'
a=ast.parse(subprocess.check_output(['git','show','5c037d8:'+p],cwd=root));z=ast.parse((root/p).read_text())
def transaction(tree):
 f=next(n for n in tree.body if isinstance(n,ast.AsyncFunctionDef) and n.name=='insert_games_months_moves_and_players')
 return ast.dump(next(n for n in f.body if isinstance(n,ast.AsyncWith)),include_attributes=False)
assert transaction(a)==transaction(z)
for name in ['chessism_api/operations/ingestion_pipeline/game_importer.py','chessism_api/operations/ingestion_pipeline/jobs.py','tests/test_ingestion_result_contract.py','tests/test_pipeline_helpers.py']:
 compile((root/name).read_bytes(),name,'exec')
record={'baseline_head':'5c037d8ede820da423f9004941a90b874dfb7510','frontend_baseline':{'tests':len(bi),'failures':len(bf)},'frontend_final':{'tests':len(gi),'failures':len(gf)},'failure_details_identical':True,'existing_test_identities_retained':True,'new_unit_tests':sorted(set(gi)-set(bi)),'frontend_testing_debt':list(bf),'backend_baseline_tests':bb['tests_run'],'backend_final_tests':bg['tests_run'],'backend_new_tests':sorted(set(bg['identities'])-set(bb['identities'])),'final_source_hashes':len(source_hashes),'source_drift':0,'protected_paths_unchanged':protected,'import_transaction_ast_unchanged':True,'python_compile_checks':4}
(e/'comparison.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
