"""One short offline gate; owns only uniquely labelled disposable containers."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import uuid

ROOT = Path('/home/jon/Desktop/workshop/last_chessism')
BASE = Path('/tmp/chessism-canonical-b-cancellation-20261119')
PG = 'sha256:9a18aed4ecdd7db9e63f876ace8ef65166d9358ece23893eed8db9b1a7fa0b95'
API = 'sha256:ba1c705b2daf726ab8c6b4036f945413585fb657590933e2673e0424970721be'
DOCKER = ['docker', '--host', 'unix:///var/run/docker.sock']

def docker(*args, check=True, timeout=35):
    result = subprocess.run([*DOCKER, *args], text=True, capture_output=True, timeout=timeout)
    if check and result.returncode:
        raise RuntimeError(f'Docker {args[0]} failed: {result.stderr.strip()}')
    return result

if __name__ == '__main__':
    stage = sys.argv[1]
    if stage.endswith('311'):
        API = 'sha256:cee894ea7424d765d8545ed2d2845e136e56691bf52d8d20a443b92ecc5210a6'
    assert stage.replace('-', '').isalnum()
    assert stage in json.loads((BASE/'suites.json').read_text())
    owner = 'chessism-b-cancel-' + uuid.uuid4().hex[:10]
    socket = BASE / owner
    socket.mkdir(mode=0o777)
    socket.chmod(0o777)
    created = []
    record = {'stage': stage, 'owner': owner, 'images': {'postgres':PG, 'python':API},
              'socket':str(socket), 'network':'none', 'ports':[], 'cleanup':[]}
    baseline_mounts = []
    if stage.startswith('redchecked'):
        record['baseline_overrides'] = {}
        for relative in ['chessism_api/operations/engine_client.py', 'stockfish-service/operations/engine.py', 'stockfish-service/routers/analysis.py']:
            original = BASE / 'baseline' / relative
            record['baseline_overrides'][relative] = hashlib.sha256(original.read_bytes()).hexdigest()
            baseline_mounts.extend(['--mount', f'type=bind,source={original},target=/workspace/{relative},readonly'])
        record['baseline_commit'] = '62563a6a0e5091e5b7aa44afc03fafcdf5a7c367'
    tracked = subprocess.check_output(['git','ls-files','*.py','*.sql'], cwd=ROOT, text=True).splitlines()
    tracked += subprocess.check_output(['git','ls-files','--others','--exclude-standard','*.py'], cwd=ROOT, text=True).splitlines()
    hashes = {name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in tracked if (ROOT/name).is_file()}
    hashes.update(record.get('baseline_overrides', {}))
    (BASE/'evidence'/f'{stage}-hashes.json').write_text(json.dumps(hashes,sort_keys=True,indent=2)+'\n')
    started = time.monotonic()
    try:
        pg_name = owner+'-pg'
        docker('create','--pull','never','--name',pg_name,'--label','chessism.stage_b.correction='+owner,
               '--network','none','--read-only','--user','1000:1000','--cpus','2','--memory','1g','--pids-limit','128',
               '--tmpfs','/tmp:rw,size=1g','--tmpfs','/var/lib/postgresql/data:rw,size=1m',
               '--mount',f'type=bind,source={socket},target=/var/run/postgresql',
               '--env','PGDATA=/tmp/pgdata','--env','POSTGRES_USER=test',
               '--env','POSTGRES_HOST_AUTH_METHOD=trust','--env','POSTGRES_DB=chessism_canonical_test',
               '--env','PGPORT=55432',PG,'-c','listen_addresses=','-c','port=55432',
               '-c','unix_socket_directories=/var/run/postgresql')
        created.append(pg_name)
        docker('start',pg_name)
        deadline = time.monotonic()+30
        while True:
            ready = docker('exec',pg_name,'sh','-c',
                'test "$(cat /proc/1/comm)" = postgres && pg_isready -h /var/run/postgresql -p 55432 -U test -d chessism_canonical_test',check=False)
            if ready.returncode == 0: break
            if time.monotonic()>deadline: raise RuntimeError('Disposable PostgreSQL did not become ready')
            time.sleep(.25)
        redis_name = owner+'-redis'
        docker('create','--pull','never','--name',redis_name,'--label','chessism.stage_b.correction='+owner,
               '--network','none','--read-only','--user','1000:1000','--memory','128m','--pids-limit','32',
               '--mount',f'type=bind,source={socket},target={socket}',
               '--entrypoint','redis-server','sha256:2a51817f79255c8b69f86a974459c2e0359aff81417d80158f2b9e541e6f4b33',
               '--port','0','--unixsocket',str(socket/'redis.sock'),'--unixsocketperm','777','--save','','--appendonly','no')
        created.append(redis_name)
        docker('start',redis_name)
        deadline = time.monotonic()+10
        while not (socket/'redis.sock').exists():
            if time.monotonic()>deadline: raise RuntimeError('Isolated Redis not ready')
            time.sleep(.05)
        runner = owner+'-tests'
        docker('create','--pull','never','--name',runner,'--label','chessism.stage_b.correction='+owner,
               '--network','none','--read-only','--user','1000:1000','--cpus','2','--memory','2g','--pids-limit','256',
               '--tmpfs','/tmp:rw,size=256m',
               '--mount',f'type=bind,source={ROOT},target=/workspace,readonly',
               '--mount','type=bind,source=/dev/null,target=/workspace/.env,readonly',
               '--mount',f'type=bind,source={BASE}/run_tests.py,target=/run_tests.py,readonly',
               '--mount',f'type=bind,source={BASE}/suites.json,target=/suites.json,readonly',
               '--mount',f'type=bind,source={BASE}/evidence,target=/evidence',
               '--mount',f'type=bind,source={socket},target={socket}',
               '--workdir','/workspace','--env','PYTHONDONTWRITEBYTECODE=1','--env','PYTHONUNBUFFERED=1',
               '--env','PYTHONPATH=/workspace:/workspace/tests:/workspace/stockfish-batch-worker:/workspace/stockfish-service:/workspace/stockfish-batch-worker/tests',
               '--env',f'CHESSISM_CANONICAL_TEST_SOCKET={socket}',
               '--env',f'CHESSISM_ANALYSIS_TEST_REDIS_URL=unix://{socket}/redis.sock',
               '--env','DATABASE_URL=postgresql+asyncpg://test:test@127.0.0.1:1/test',
               '--env','AUTH_COOKIE_NAME=synthetic_session','--env','AUTH_GATE_COOKIE_NAME=synthetic_gate',
               '--env','AUTH_SESSION_TTL_DAYS=1','--env','AUTH_GATE_TTL_MINUTES=1',
               '--env','AUTH_COOKIE_SECURE=false','--env','SUPERADMIN_GATE_CODE=synthetic-only',
               *baseline_mounts, '--entrypoint','python',API,'-B','/run_tests.py',stage)
        created.append(runner)
        with (BASE/'evidence'/f'{stage}.log').open('w') as out:
            completed = subprocess.run([*DOCKER,'start','--attach',runner],stdout=out,stderr=subprocess.STDOUT,timeout=200)
        state = json.loads(docker('inspect',runner,'--format','{{json .State}}').stdout)
        record['state'] = state
        record['exit_code'] = state['ExitCode']
        print(f'{stage}: exit={state["ExitCode"]}; log={BASE}/evidence/{stage}.log',flush=True)
    finally:
        for name in reversed(created):
            identity = json.loads(docker('inspect',name,'--format','{{json .Config.Labels}}').stdout)
            assert identity.get('chessism.stage_b.correction') == owner
            state = json.loads(docker('inspect',name,'--format','{{json .State}}').stdout)
            if state['Running']: docker('stop','--timeout','30',name,timeout=40)
            if name.endswith('-pg'):
                (BASE/'evidence'/f'{stage}-postgres.log').write_text(docker('logs',name).stdout+docker('logs',name).stderr)
            docker('rm',name)
            record['cleanup'].append({'name':name,'removed':docker('inspect',name,check=False).returncode!=0})
        record['elapsed_seconds']=time.monotonic()-started
        (BASE/'evidence'/f'{stage}-environment.json').write_text(json.dumps(record,indent=2)+'\n')
    sys.exit(record.get('exit_code',1))
