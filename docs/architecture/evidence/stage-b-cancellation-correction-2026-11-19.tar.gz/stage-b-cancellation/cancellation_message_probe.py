import asyncio,sys
from stockfish_core.deadlines import wait_with_timeout
async def main():
 for mode in ('plain','deadline'):
  entered,release=asyncio.Event(),asyncio.Event()
  async def operation():
   entered.set();await release.wait();return 42
  async def parent():
   try:
    if mode=='plain':return await operation()
    return await wait_with_timeout(operation(),10)
   except asyncio.CancelledError as error:
    print(mode,'inside consumer',repr(error.args),id(error))
    raise
  task=asyncio.create_task(parent());await entered.wait();release.set();task.cancel('original')
  try:await task
  except asyncio.CancelledError as error:print(mode,'outside Task await',repr(error.args),id(error))
 print(sys.version)
asyncio.run(main())
