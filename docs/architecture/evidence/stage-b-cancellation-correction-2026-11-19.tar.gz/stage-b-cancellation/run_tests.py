import json
from pathlib import Path
import sys,time,unittest
class Result(unittest.TextTestResult):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs);self.identities=[]
    def startTest(self,test):
        self.identities.append(test.id());super().startTest(test)
if __name__=='__main__':
    stage=sys.argv[1];names=json.loads(Path('/suites.json').read_text())[stage]
    if stage.startswith('baseline'):
        import inspect
        from arq.connections import ArqRedis
        print('ARQ_ENQUEUE_SIGNATURE',inspect.signature(ArqRedis.enqueue_job),flush=True)
    start=time.monotonic()
    suite=unittest.defaultTestLoader.loadTestsFromNames(names)
    r=unittest.TextTestRunner(verbosity=2,resultclass=Result).run(suite)
    record={'stage':stage,'runtime':sys.version,'selected':names,'tests_run':r.testsRun,
            'identities':r.identities,'elapsed_seconds':time.monotonic()-start,
            'failures':[(t.id(),e) for t,e in r.failures],'errors':[(t.id(),e) for t,e in r.errors],
            'skipped':[(t.id(),e) for t,e in r.skipped],'successful':r.wasSuccessful()}
    Path('/evidence/'+stage+'-results.json').write_text(json.dumps(record,indent=2)+'\n')
    sys.exit(0 if r.wasSuccessful() and not r.skipped else 1)
