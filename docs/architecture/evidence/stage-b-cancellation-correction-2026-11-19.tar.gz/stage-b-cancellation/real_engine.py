import json,subprocess,time,uuid
from pathlib import Path
base=Path('/tmp/chessism-canonical-b-cancellation-20261119/evidence')
image='sha256:8b1a8b0a7db5f3dcbacccc2d7a3b8c436c0d66fe26ee96dfea4e428ddd7dff9a'
name='chessism-b-cancel-real-'+uuid.uuid4().hex[:8]
docker=['docker','--host','unix:///var/run/docker.sock']
args=['create','--pull','never','--name',name,'--label','chessism.stage_b.correction='+name,
 '--network','none','--read-only','--user','1000:1000','--cpus','2','--memory','1g','--pids-limit','64',
 '--tmpfs','/tmp:rw,size=128m','--mount','type=bind,source=/home/jon/Desktop/workshop/last_chessism,target=/workspace,readonly',
 '--mount','type=bind,source=/dev/null,target=/workspace/.env,readonly',
 '--workdir','/workspace','--env','PYTHONDONTWRITEBYTECODE=1','--env','STOCKFISH_ENGINE_COUNT=1',
 '--env','PYTHONPATH=/workspace:/workspace/tests:/workspace/stockfish-service:/workspace/stockfish-batch-worker',
 '--entrypoint','python',image,'-B','tests/check_real_stockfish_service.py']
started=time.monotonic();created=False;record={'image':image,'command':args,'network':'none'}
try:
 subprocess.run(docker+args,check=True,capture_output=True);created=True
 with (base/'real-engine.log').open('w') as log:
  subprocess.run(docker+['start','--attach',name],stdout=log,stderr=subprocess.STDOUT,timeout=60)
 record['state']=json.loads(subprocess.check_output(docker+['inspect',name,'--format','{{json .State}}'],text=True))
finally:
 if created:
  state=json.loads(subprocess.check_output(docker+['inspect',name,'--format','{{json .State}}'],text=True))
  if state['Running']:subprocess.run(docker+['stop','--timeout','15',name],check=True,capture_output=True)
  subprocess.run(docker+['rm',name],check=True,capture_output=True)
  record['removed']=subprocess.run(docker+['inspect',name],capture_output=True).returncode!=0
 record['elapsed_seconds']=time.monotonic()-started
 (base/'real-engine-environment.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'exit':record.get('state',{}).get('ExitCode'),'elapsed':record['elapsed_seconds'],'removed':record.get('removed')}))
raise SystemExit(record.get('state',{}).get('ExitCode',1))
